# Randy-Tantrum
Randy Tantrum(A Random Tryrantum)|Guzzle Humdrum
Jubilee Hands-On
Strawberry Facepalm
Charlie Doldrum
Modally Hologram
[Gladly Syndrome,Simile Popcorn]
Lastly Ghastly Phantom(Lastly a Ghastly Phantom)
